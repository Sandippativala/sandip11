function validate() {
    isValid = true;

    // FullName Validation
    let fullName = document.getElementById("name").value;
    let patternFullName = /^(?=.{8,40}$)[a-zA-Z][a-zA-Z]*(?: [a-zA-Z]+){0,2}$/;
    let errorFullName = document.getElementById("errorFullName");

    if (patternFullName.test(fullName) === false) {
        errorFullName.innerHTML = "Fullname must be 8-40 characters.";
        isValid = false;
    } else {
        errorFullName.innerHTML = "";
    }

    // Enrollment Number Validation
    let enrollmentNumber = document.getElementById("enrollment").value;
    let patternEnrollmentNumber = /^[1-9][0-9]{5,19}$/;
    let errorEnrollmentNumber = document.getElementById("errorEnrollmentNumber");

    if (patternEnrollmentNumber.test(enrollmentNumber) === false) {
        errorEnrollmentNumber.innerHTML =
                "Invalid! Enter an 8-20 digit Enrollment Number.";
        isValid = false;
    } else {
        errorEnrollmentNumber.innerHTML = "";
    }

    // Birth Date Validation
    let birthDate = document.getElementById("dob").value;
    let errorBirthdate = document.getElementById("errorDOB");

    if (!birthDate) {
        errorBirthdate.innerHTML = "Please enter your birth date.";
        isValid = false;
    } else {
        let today = new Date();
        let birthDateObj = new Date(birthDate);
        let age = today.getFullYear() - birthDateObj.getFullYear();

        let monthDiff = today.getMonth() - birthDateObj.getMonth();
        if (
                monthDiff < 0 ||
                (monthDiff === 0 && today.getDate() < birthDateObj.getDate())
                ) {
            age--;
        }

        if (age < 16) {
            errorBirthdate.innerHTML = "You must be at least 16 years old.";
            isValid = false;
        } else {
            errorBirthdate.innerHTML = "";
        }
    }

    // Gender Validation
    let gender = document.querySelector('input[name="gender"]:checked');
    let errorGender = document.getElementById("errorGender");

    if (!gender) {
        errorGender.innerHTML = "Please select a gender.";
        isValid = false;
    } else {
        errorGender.innerHTML = "";
    }

    // Course Validation
    let course = document.getElementById("course").value;
    let errorCourse = document.getElementById("errorCourse");

    if (
            course !== "btech" &&
            course !== "mtech" &&
            course !== "bca" &&
            course !== "mca" &&
            course !== "bba" &&
            course !== "mba"
            ) {
        errorCourse.innerHTML = "Enter a valid course.";
        isValid = false;
    } else {
        errorCourse.innerHTML = "";
    }

    // Year of Study Validation
    let yearOfStudy = document.getElementById("year").value;
    let errorYearOfStudy = document.getElementById("errorYear");

    if (
            yearOfStudy !== "1" &&
            yearOfStudy !== "2" &&
            yearOfStudy !== "3" &&
            yearOfStudy !== "4"
            ) {
        errorYearOfStudy.innerHTML = "Enter a valid year.";
        isValid = false;
    } else {
        errorYearOfStudy.innerHTML = "";
    }

    // Email Validation
    let email = document.getElementById("email").value;
    let patternEmail =
            /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.(com|org|net|info|biz|pro|edu|gov|mil|int|ai|io|tech|store|online|site|xyz|finance|media|design|photography|museum|travel|blog|app|dev|cloud|solutions|company|consulting|academy|family|news|club|fashion|shop|vip|love|wiki|eco|space|dog|beer|fun|ninja|guru|rocks|ac\.in|co\.in|gov\.in|edu\.in|res\.in|net\.in|org\.in|ac\.uk|co\.uk|gov\.uk|org\.uk|ltd\.uk|plc\.uk|net\.uk|sch\.uk|com\.au|net\.au|org\.au|edu\.au|gov\.au|co\.nz|org\.nz|ac\.nz|govt\.nz|co\.za|org\.za|gov\.za|ac\.za|net\.za|com\.br|net\.br|gov\.br|org\.br|edu\.br|mil\.br|com\.cn|gov\.cn|edu\.cn|com\.jp|co\.jp|or\.jp|ac\.jp|go\.jp|com\.hk|org\.hk|edu\.hk|gov\.hk|net\.hk)$/i;
    let errorEmail = document.getElementById("errorEmail");

    if (patternEmail.test(email) === false) {
        errorEmail.innerHTML = "Enter a valid email.";
        isValid = false;
    } else {
        errorEmail.innerHTML = "";
    }

    // Phone Number Validation
    let phone = document.getElementById("phone").value;
    let patternPhone = /^[6-9][0-9]{9}$/;
    let errorPhone = document.getElementById("errorPhone");

    if (patternPhone.test(phone) === false) {
        errorPhone.innerHTML = "Enter a valid 10-digit mobile number.";
        isValid = false;
    } else {
        errorPhone.innerHTML = "";
    }

    // Address Validation
    let address = document.getElementById("address").value;
    let patternAddress =
            /^(?=.{10,100}$)[a-zA-Z0-9][a-zA-Z0-9:,.-]*(?: (?! )[a-zA-Z0-9:,.-]+){0,4}$/;
    let errorAddress = document.getElementById("errorAddress");

    if (patternAddress.test(address) === false) {
        errorAddress.innerHTML = "Address must be 10-100 characters long.";
        isValid = false;
    } else {
        errorAddress.innerHTML = "";
    }

    // Image Photo Validation
    let image = document.getElementById("photo");
    let errorImage = document.getElementById("errorPhoto");

    if (!image.files.length) {
        errorImage.innerHTML = "Please upload an image.";
        isValid = false;
    } else {
        let file = image.files[0];
        if (file && !/\.(jpg|jpeg)$/i.test(file.name)) {
            errorImage.innerHTML = "Only JPG or JPEG images are allowed.";
            isValid = false;
        } else {
            errorImage.innerHTML = "";
        }
    }

    return isValid;
}