/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlet;

import dao.UserDAO;
import entity.User;
import jakarta.servlet.RequestDispatcher;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.sql.SQLException;

/**
 *
 * @author neelj
 */
public class FetchStudent extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("update"));

        try {
            UserDAO udao = new UserDAO();
            User user = udao.getStudent(id);
            if (user != null) {
                request.setAttribute("fullName", user.getFullName());
                request.setAttribute("enrollmentNumber", user.getEnrollmentNumber());
                request.setAttribute("dob", user.getDob());
                request.setAttribute("gender", user.getGender());
                request.setAttribute("course", user.getCourse());
                request.setAttribute("yearOfStudy", user.getYearOfStudy());
                request.setAttribute("email", user.getEmail());
                request.setAttribute("phone", user.getPhone());
                request.setAttribute("address", user.getAddress());
                request.setAttribute("photoName", user.getPhotoName());
                RequestDispatcher rd = request.getRequestDispatcher("update.jsp");
                rd.forward(request, response);
            }else{
                System.err.println("Not Found User.");
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
    }
}
