/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlet;

import dao.UserDAO;
import entity.User;
import helper.FileOperation;
import jakarta.servlet.RequestDispatcher;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.regex.Pattern;

/**
 *
 * @author neelj
 */
@MultipartConfig
public class Register extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        PrintWriter out = response.getWriter();

        // User Data
        String fullName = request.getParameter("fullName");
        String enrollmentNumber = request.getParameter("enrollmentNumber");
        String dob = request.getParameter("dob");
        String gender = request.getParameter("gender");
        String course = request.getParameter("course");
        String yearOfStudy = request.getParameter("year");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String address = request.getParameter("address");
        Part photo = request.getPart("photo");
        String photoName = photo.getSubmittedFileName();

        // Set Attribute
        request.setAttribute("fullName", fullName);
        request.setAttribute("enrollmentNumber", enrollmentNumber);
        request.setAttribute("dob", dob);
        request.setAttribute("gender", gender);
        request.setAttribute("course", course);
        request.setAttribute("yearOfStudy", yearOfStudy);
        request.setAttribute("email", email);
        request.setAttribute("phone", phone);
        request.setAttribute("address", address);

        // User Data Validation
        boolean isValid = true;

        // FullName Validation
        String patternFullName = "^(?=.{8,40}$)[a-zA-Z][a-zA-Z]*(?: [a-zA-Z]+){0,2}$";

        if (Pattern.matches(patternFullName, fullName) == false) {
            request.setAttribute("errorFullName", "Fullname must be 8-40 characters.");
            isValid = false;
        }

        // Enrollment Number Validation
        String patternEnrollmentNumber = "^[1-9][0-9]{5,19}$";

        if (Pattern.matches(patternEnrollmentNumber, enrollmentNumber) == false) {
            request.setAttribute("errorEnrollmentNumber", "Invalid! Enter an 8-20 digit Enrollment Number.");
        }

        // DOB Validation
        if (dob == null || dob.equals("")) {
            request.setAttribute("errorDOB", "Please enter your birth date.");
            isValid = false;
        } else {
            LocalDate today = LocalDate.now();
            LocalDate birthDate = LocalDate.parse(dob);
            int age = today.getYear() - birthDate.getYear();
            int monthDiff = today.getMonthValue() - birthDate.getMonthValue();

            if (monthDiff < 0 || (monthDiff == 0 && today.getDayOfMonth() < birthDate.getDayOfMonth())) {
                age--;
            }

            if (age < 16) {
                request.setAttribute("errorDOB", "You must be at least 16 years old.");
                isValid = false;
            }
        }

        // Gender Validation
        if (gender == null) {
            request.setAttribute("errorGender", "Please select a gender.");
            isValid = false;
        }

        // Course Validation
        if (course == null) {
            request.setAttribute("errorCourse", "Enter a valid Course.");
            isValid = false;
        }

        // yearOfStudy Validation
        if (yearOfStudy == null) {
            request.setAttribute("errorYearOfStudy", "Enter a valid Year.");
            isValid = false;
        }

        // Email Validation
        String patternEmail = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.(com|org|net|info|biz|pro|edu|gov|mil|int|ai|io|tech|store|online|site|xyz|finance|media|design|photography|museum|travel|blog|app|dev|cloud|solutions|company|consulting|academy|family|news|club|fashion|shop|vip|love|wiki|eco|space|dog|beer|fun|ninja|guru|rocks|ac\\.in|co\\.in|gov\\.in|edu\\.in|res\\.in|net\\.in|org\\.in|ac\\.uk|co\\.uk|gov\\.uk|org\\.uk|ltd\\.uk|plc\\.uk|net\\.uk|sch\\.uk|com\\.au|net\\.au|org\\.au|edu\\.au|gov\\.au|co\\.nz|org\\.nz|ac\\.nz|govt\\.nz|co\\.za|org\\.za|gov\\.za|ac\\.za|net\\.za|com\\.br|net\\.br|gov\\.br|org\\.br|edu\\.br|mil\\.br|com\\.cn|gov\\.cn|edu\\.cn|com\\.jp|co\\.jp|or\\.jp|ac\\.jp|go\\.jp|com\\.hk|org\\.hk|edu\\.hk|gov\\.hk|net\\.hk)$";

        if (Pattern.matches(patternEmail, email) == false) {
            request.setAttribute("errorEmail", "Enter a valid email.");
            isValid = false;
        }

        // Phone Validation
        String patternMobile = "[6-9][0-9]{9}$";

        if (Pattern.matches(patternMobile, phone) == false) {
            request.setAttribute("errorPhone", "Enter a valid 10-digit mobile number.");
            isValid = false;
        }

        // Address Validation
        String patternAddress = "^(?=.{10,100}$)[a-zA-Z0-9][a-zA-Z0-9:,.-]*(?: (?! )[a-zA-Z0-9:,.-]+){0,4}$";

        if (Pattern.matches(patternAddress, address) == false) {
            request.setAttribute("errorAddress", "Address must be 10-100 characters long.");
            isValid = false;
        }

        // Photo Validation
        if (photo.getSize() == 0) {
            request.setAttribute("errorPhoto", "Please upload an image.");
            isValid = false;
        }

        RequestDispatcher rd = request.getRequestDispatcher("registration.jsp");
        // Store data in Database
        if (isValid) {
            User user = new User(fullName, enrollmentNumber, dob, gender, course, yearOfStudy, email, phone, address, photo, photoName);

            if (FileOperation.addPhoto(photo, photoName)) {
                try {
                    UserDAO udao = new UserDAO();
                    int result = udao.addStudent(user);

                    if (result == 1) {
                        request.setAttribute("errorMsg", "Allready student exists.");
                        rd.forward(request, response);
                    } else {
                        response.sendRedirect(request.getContextPath());
                    }
                } catch (SQLException e) {
                    System.err.println(e.getMessage());
                }
            } else {
                System.out.println("Photo Upload Failed.");
            }
        } else {
            rd.forward(request, response);
        }
    }
}
