/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package helper;

import jakarta.servlet.http.Part;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 *
 * @author neelj
 */
public class FileOperation {

    // Delete Photo
    public static boolean deletePhoto(String photoName) {
        String path = "D:\\Documents\\MCA\\MCA-202\\WebApplication5\\web\\images\\" + photoName;
        File file = new File(path);
        if (file.exists()) {
            try {
                return file.delete();
            } catch (SecurityException e) {
                System.err.println("Error deleting file: " + e.getMessage());
            }
        }
        return false;
    }

    // Upload Photo
    public static boolean addPhoto(Part Photo, String PhotoName) {
        try {
            InputStream is = Photo.getInputStream();
            byte data[] = new byte[is.available()];
            is.read(data);

            String path = "D:\\Documents\\MCA\\MCA-202\\WebApplication5\\web\\images\\" + PhotoName;
            FileOutputStream fos = new FileOutputStream(path);
            fos.write(data);
            fos.flush();
            fos.close();
            return true;
        } catch (IOException e) {
            System.err.println(e.getMessage());
            return false;
        }
    }
}
