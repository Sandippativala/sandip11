/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package helper;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author neelj
 */
public class ConnectionProvider {

    private static Connection connection=null;

    public static synchronized Connection getConnection() {

        if (connection == null) {
            try {
                
                Class.forName("com.mysql.cj.jdbc.Driver");
                
                String url = "jdbc:mysql://localhost:3306/gvp";
                String user = "root";
                String password = "455445";

                connection = DriverManager.getConnection(url, user, password);
            } catch (SQLException | ClassNotFoundException e) {
                System.err.println(e.getMessage());
            }
        }
        return connection;
    }
}
