/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import entity.User;
import helper.ConnectionProvider;
import helper.FileOperation;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author neelj
 */
public class UserDAO {

    private Connection connection;

    public UserDAO() {
        connection = ConnectionProvider.getConnection();
    }

    // Add Student
    public int addStudent(User user) throws SQLException, IOException {
        PreparedStatement psmt;
        ResultSet rsSearch;

        // Check Student AllReady Exists or Not
        String sqlSearchStudent = "select * from student where enrollment_number=?";
        psmt = connection.prepareStatement(sqlSearchStudent);
        psmt.setString(1, user.getEnrollmentNumber());
        rsSearch = psmt.executeQuery();

        if (rsSearch.next()) {
            return 1;
        } else {
            String sqlAdd = "insert into student(fullname,enrollment_number,dob,gender,course,year_of_study,email,phone,address,photo) values(?,?,?,?,?,?,?,?,?,?)";
            psmt = connection.prepareStatement(sqlAdd);

            psmt.setString(1, user.getFullName());
            psmt.setString(2, user.getEnrollmentNumber());
            psmt.setString(3, user.getDob());
            psmt.setString(4, user.getGender());
            psmt.setString(5, user.getCourse());
            psmt.setString(6, user.getYearOfStudy());
            psmt.setString(7, user.getEmail());
            psmt.setString(8, user.getPhone());
            psmt.setString(9, user.getAddress());
            psmt.setString(10, user.getPhotoName());
            psmt.executeUpdate();
            return 2;
        }
    }

    // Delete Student
    public boolean deleteStudent(int id) throws SQLException, NullPointerException {
        // Serach Photo
        String sqlPhotoSearch = "select * from student where id=?";
        PreparedStatement psmtPhotoSearch = connection.prepareStatement(sqlPhotoSearch);
        psmtPhotoSearch.setInt(1, id);
        ResultSet rs = psmtPhotoSearch.executeQuery();

        // delete record
        String sqlDelete = "delete from student where id=?";
        PreparedStatement psmt = connection.prepareStatement(sqlDelete);
        psmt.setInt(1, id);
        int row = psmt.executeUpdate();
        if (row == 1) {
            rs.next();
            FileOperation.deletePhoto(rs.getString("photo"));
            return true;
        }
        return false;
    }

    // Get Student Details
    public User getStudent(int id) throws SQLException {
        User user = null;

        // get Student all details
        String sqlStudent = "select * from student where id=?";
        PreparedStatement psmt = connection.prepareStatement(sqlStudent);
        psmt.setInt(1, id);
        ResultSet rs = psmt.executeQuery();
        if (rs.next()) {
            int sid = rs.getInt(1);
            String fullName = rs.getString(2);
            String enrollmentNumber = rs.getString(3);
            String dob = rs.getString(4);
            String gender = rs.getString(5);
            String course = rs.getString(6);
            String yearOfStudy = rs.getString(7);
            String email = rs.getString(8);
            String phone = rs.getString(9);
            String address = rs.getString(10);
            String photoName = rs.getString(11);
            user = new User(sid, fullName, enrollmentNumber, dob, gender, course, yearOfStudy, email, phone, address, photoName);
        }
        return user;
    }

    // Update Student Details
    public int updateStudent(User user) throws SQLException {
        PreparedStatement psmt;

        if (user.getPhoto().getSize() == 0) {
            String sqlUpdate = "update student set fullname=?,dob=?,course=?,year_of_study=?,email=?,phone=?,address=? where enrollment_number=?";
            psmt = connection.prepareStatement(sqlUpdate);

            psmt.setString(1, user.getFullName());
            psmt.setString(2, user.getDob());
            psmt.setString(3, user.getCourse());
            psmt.setString(4, user.getYearOfStudy());
            psmt.setString(5, user.getEmail());
            psmt.setString(6, user.getPhone());
            psmt.setString(7, user.getAddress());
            psmt.setString(8, user.getEnrollmentNumber());
            psmt.executeUpdate();
            return 1;
        } else {
            // Serach Photo
            String sqlPhotoSearch = "select * from student where enrollment_number=?";
            PreparedStatement psmtPhotoSearch = connection.prepareStatement(sqlPhotoSearch);
            psmtPhotoSearch.setString(1, user.getEnrollmentNumber());
            ResultSet rs = psmtPhotoSearch.executeQuery();
            if (rs.next()) {
                if (FileOperation.deletePhoto(rs.getString("photo"))) {
                    System.out.println("Successfull photo delete."+rs.getString("photo"));
                }
                if (FileOperation.addPhoto(user.getPhoto(), user.getPhotoName())) {
                    System.out.println("Successfull Photo Update."+user.getPhotoName());
                }
            }

            String sqlUpdate = "update student set fullname=?,dob=?,course=?,year_of_study=?,email=?,phone=?,address=?,photo=? where enrollment_number=?";
            psmt = connection.prepareStatement(sqlUpdate);

            psmt.setString(1, user.getFullName());
            psmt.setString(2, user.getDob());
            psmt.setString(3, user.getCourse());
            psmt.setString(4, user.getYearOfStudy());
            psmt.setString(5, user.getEmail());
            psmt.setString(6, user.getPhone());
            psmt.setString(7, user.getAddress());
            psmt.setString(8, user.getPhotoName());
            psmt.setString(9, user.getEnrollmentNumber());
            psmt.executeUpdate();

            return 2;
        }
    }
}
