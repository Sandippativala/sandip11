/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import jakarta.servlet.http.Part;

/**
 *
 * @author neelj
 */
public class User {

    private int id;
    private String fullName;
    private String enrollmentNumber;
    private String dob;
    private String gender;
    private String course;
    private String yearOfStudy;
    private String email;
    private String phone;
    private String address;
    private Part photo;
    private String photoName;

    public User(int id, String fullName, String enrollmentNumber, String dob, String gender, String course, String yearOfStudy, String email, String phone, String address, String photoName) {
        this.id = id;
        this.fullName = fullName;
        this.enrollmentNumber = enrollmentNumber;
        this.dob = dob;
        this.gender = gender;
        this.course = course;
        this.yearOfStudy = yearOfStudy;
        this.email = email;
        this.phone = phone;
        this.address = address;
        this.photoName = photoName;
    }

    public User(String fullName, String enrollmentNumber, String dob, String gender, String course, String yearOfStudy, String email, String phone, String address, Part photo, String photoName) {
        this.fullName = fullName;
        this.enrollmentNumber = enrollmentNumber;
        this.dob = dob;
        this.gender = gender;
        this.course = course;
        this.yearOfStudy = yearOfStudy;
        this.email = email;
        this.phone = phone;
        this.address = address;
        this.photo = photo;
        this.photoName = photoName;
    }

    public User() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getEnrollmentNumber() {
        return enrollmentNumber;
    }

    public void setEnrollmentNumber(String enrollmentNumber) {
        this.enrollmentNumber = enrollmentNumber;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    public String getYearOfStudy() {
        return yearOfStudy;
    }

    public void setYearOfStudy(String yearOfStudy) {
        this.yearOfStudy = yearOfStudy;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Part getPhoto() {
        return photo;
    }

    public void setPhoto(Part photo) {
        this.photo = photo;
    }

    public String getPhotoName() {
        return photoName;
    }

    public void setPhotoName(String photoName) {
        this.photoName = photoName;
    }
}
