/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlet;

import dao.UserDAO;
import entity.User;
import jakarta.servlet.RequestDispatcher;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.sql.SQLException;
import java.util.regex.*;

/**
 *
 * @author neelj
 */
public class Registration extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            response.setContentType("text/html");
            PrintWriter pw = response.getWriter();

            // Fetching all relevant data based on the user's request
            String firstName = request.getParameter("user_first_name");
            String lastName = request.getParameter("user_last_name");
            String email = request.getParameter("user_email");
            String mobile = request.getParameter("user_mobile");
            String address = request.getParameter("user_address");
            String password = request.getParameter("user_password");
            String confirmPassword = request.getParameter("user_confirm_password");
            String userRoll = request.getParameter("user_roll");

            // Set All Data in Atribute
            request.setAttribute("firstName", firstName);
            request.setAttribute("lastName", lastName);
            request.setAttribute("email", email);
            request.setAttribute("mobile", mobile);
            request.setAttribute("address", address);
            request.setAttribute("userRoll", userRoll);

            boolean isValid = true;

            // FirstName Validation
            String patternFirstName = "^[a-zA-Z]{6,40}$";
            if (Pattern.matches(patternFirstName, firstName) == false) {
                request.setAttribute("errorFirstName", "First name must be 6-40 letters, no spaces.");
                isValid = false;
            }

            // LastName Validation
            String patternLastName = "^[a-zA-Z]{6,40}$";
            if (Pattern.matches(patternLastName, lastName) == false) {
                request.setAttribute("errorLastName", "Last name must be 6-40 letters, no spaces.");
                isValid = false;
            }

            // Email Validation
            String patternEmail = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
            if (Pattern.matches(patternEmail, email) == false) {
                request.setAttribute("errorEmail", "Enter a valid email.");
                isValid = false;
            }

            // Mobile Validation
            String patternMobile = "^[0-9]{10}$";
            if (Pattern.matches(patternMobile, mobile) == false) {
                request.setAttribute("errorMobile", "Enter a valid 10-digit mobile number.");
                isValid = false;
            }

            // Address Validation
            String patternAddress = "^[a-zA-Z0-9\\s,.'-]{10,100}";
            if (Pattern.matches(patternAddress, address) == false) {
                request.setAttribute("errorAddress", "Address must be 10-100 characters long.");
                isValid = false;
            }

            // Password Validation
            String patternPassword = "^[a-zA-Z0-9!@#$%^&*,.]{6,20}$";
            if (Pattern.matches(patternPassword, password) == false) {
                request.setAttribute("errorPassword", "Password must be 8-16 characters long, no spaces.");
                isValid = false;
            }

            // ConfirmPassword Validation
            if (confirmPassword.equals(password) == false) {
                request.setAttribute("errorConfirmPassword", "Passwords mismatch. Retry");
            }

            // Role Validation
            if (userRoll == null) {
                request.setAttribute("errorRole", "Select the Role.");
                isValid = false;
            }

            if (isValid) {
                // Set User Data in Entity
                User u = new User(firstName, lastName, email, mobile, address, password, userRoll);

                // Pass User Entity Object to UserDAO for Storing Data in the Database
                UserDAO udao = new UserDAO();
                int result = udao.addUser(u);

                if (result == 1) {
                    request.setAttribute("msg", "Successfully Registration.");

                } else if (result == 2) {
                    request.setAttribute("msg", "This email is already in use.");
                } else {
                    request.setAttribute("msg", "Something went wrong. Please try again later.");
                }
            }

            RequestDispatcher rd1 = request.getRequestDispatcher("registration.jsp");
            rd1.forward(request, response);
        } catch (IOException | NumberFormatException | SQLException e) {
            System.err.println(e.getMessage());
        }
    }
}
