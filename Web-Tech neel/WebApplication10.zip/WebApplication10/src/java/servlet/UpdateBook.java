/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlet;

import dao.BookDAO;
import entity.Book;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.sql.SQLException;

/**
 *
 * @author neelj
 */
public class UpdateBook extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String title = request.getParameter("title");
        String author = request.getParameter("author");
        double price = Double.parseDouble(request.getParameter("price"));
        int qty = Integer.parseInt(request.getParameter("quantity"));
        String ISBN = request.getParameter("isbn");
        String publisher = request.getParameter("publisher");
        String editionYear = request.getParameter("editionYear");
        String cataLogID = request.getParameter("catalogueId");
        HttpSession session = request.getSession();
        Book book = (Book) session.getAttribute("book");
        int book_id = book.getBookID();

        // Set in Attribute
        request.setAttribute("title", title);
        request.setAttribute("author", author);
        request.setAttribute("price", price);
        request.setAttribute("qty", qty);
        request.setAttribute("ISBN", ISBN);
        request.setAttribute("publisher", publisher);
        request.setAttribute("editionYear", editionYear);
        request.setAttribute("cataLogID", cataLogID);

        try {
            BookDAO bdao = new BookDAO();
            boolean result = bdao.updateBook(book_id, title, author, price, qty, ISBN, publisher, editionYear, cataLogID);
            if (result) {
                response.sendRedirect(request.getContextPath());
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
    }
}
