/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlet;

import dao.BookDAO;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.sql.*;

/**
 *
 * @author neelj
 */
public class DeleteBook extends HttpServlet {
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int book_id = Integer.parseInt(request.getParameter("bookId"));
        
        try {
            BookDAO bdao = new BookDAO();
            boolean result = bdao.deleteBook(book_id);
            if (result) {
                response.sendRedirect(request.getContextPath());
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
}
