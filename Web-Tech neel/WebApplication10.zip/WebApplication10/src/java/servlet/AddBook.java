/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlet;

import dao.BookDAO;
import entity.Book;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.sql.*;

/**
 *
 * @author neelj
 */
public class AddBook extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String title = request.getParameter("title");
        String author = request.getParameter("author");
        double price = Double.parseDouble(request.getParameter("price"));
        int qty = Integer.parseInt(request.getParameter("quantity"));
        String ISBN = request.getParameter("isbn");
        String publisher = request.getParameter("publisher");
        String editionYear = request.getParameter("editionYear");
        String cataLogID = request.getParameter("catalogueId");

        try {
            Book book = new Book(title, author, price, qty, ISBN, publisher, editionYear, cataLogID);
            BookDAO bdao = new BookDAO();
            boolean result = bdao.addBook(book);
            if (result) {
                response.sendRedirect(request.getContextPath());
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
    }
}
