function validateForm() {
    let isValid = true;

    // Reset all error states
    document.querySelectorAll('.error').forEach(input => input.classList.remove('error'));
    document.querySelectorAll('.error-message').forEach(span => {
        span.style.display = 'none';
        span.innerHTML = '';
    });

    // Title validation: Letters, numbers, and basic punctuation
    const title = document.getElementById('title');
    const titlePattern = /^[A-Za-z0-9\s.,'-]{2,}$/;
    if (!titlePattern.test(title.value.trim())) {
        title.classList.add('error');
        document.getElementById('titleError').innerHTML =
                'Title must contain at least 2 characters (letters, numbers, spaces, or .,\'-)';
        document.getElementById('titleError').style.display = 'block';
        isValid = false;
    }

    // Author validation: Letters and spaces, optional initials
    const author = document.getElementById('author');
    const authorPattern = /^[A-Za-z\s.]{2,}$/;
    if (!authorPattern.test(author.value.trim())) {
        author.classList.add('error');
        document.getElementById('authorError').innerHTML =
                'Author must contain at least 2 characters (letters, spaces, or periods)';
        document.getElementById('authorError').style.display = 'block';
        isValid = false;
    }

    // Price validation: Positive number with up to 2 decimal places
    const price = document.getElementById('price');
    const pricePattern = /^\d+(\.\d{1,2})?$/;
    if (!pricePattern.test(price.value) || parseFloat(price.value) <= 0) {
        price.classList.add('error');
        document.getElementById('priceError').innerHTML =
                'Price must be a positive number with up to 2 decimal places';
        document.getElementById('priceError').style.display = 'block';
        isValid = false;
    }

    // Quantity validation: Non-negative integer
    const quantity = document.getElementById('quantity');
    const quantityPattern = /^\d+$/;
    if (!quantityPattern.test(quantity.value) || parseInt(quantity.value) < 0) {
        quantity.classList.add('error');
        document.getElementById('quantityError').innerHTML =
                'Quantity must be a non-negative integer';
        document.getElementById('quantityError').style.display = 'block';
        isValid = false;
    }

    // ISBN validation: ISBN-10 or ISBN-13 format
    const isbn = document.getElementById('isbn');
    const isbnPattern = /^\d{9}[\dX]$/;
    if (!isbnPattern.test(isbn.value.replace(/[- ]/g, ''))) {
        isbn.classList.add('error');
        document.getElementById('isbnError').innerHTML =
                'ISBN must be exactly 10 digits (or 9 digits + X), hyphens optional';
        document.getElementById('isbnError').style.display = 'block';
        isValid = false;
    }

    // Publisher validation: Letters, numbers, and basic punctuation
    const publisher = document.getElementById('publisher');
    const publisherPattern = /^[A-Za-z0-9\s.,&'-]{2,}$/;
    if (!publisherPattern.test(publisher.value.trim())) {
        publisher.classList.add('error');
        document.getElementById('publisherError').innerHTML =
                'Publisher must contain at least 2 characters (letters, numbers, spaces, or .,&\'-)';
        document.getElementById('publisherError').style.display = 'block';
        isValid = false;
    }

    // Edition Year validation: Four-digit year between 1000-9999
    const editionYear = document.getElementById('editionYear');
    const yearPattern = /^\d{4}$/;
    if (!yearPattern.test(editionYear.value) ||
            parseInt(editionYear.value) < 1000 ||
            parseInt(editionYear.value) > 9999) {
        editionYear.classList.add('error');
        document.getElementById('editionYearError').innerHTML =
                'Edition Year must be a four-digit year between 1000 and 9999';
        document.getElementById('editionYearError').style.display = 'block';
        isValid = false;
    }

    // Catalogue ID validation: Alphanumeric with optional hyphens
    const catalogueId = document.getElementById('catalogueId');
    const cataloguePattern = /^[A-Za-z0-9-]{3,}$/;
    if (!cataloguePattern.test(catalogueId.value.trim())) {
        catalogueId.classList.add('error');
        document.getElementById('catalogueIdError').innerHTML =
                'Catalogue ID must be at least 3 characters (letters, numbers, or hyphens)';
        document.getElementById('catalogueIdError').style.display = 'block';
        isValid = false;
    }

    return isValid;
}