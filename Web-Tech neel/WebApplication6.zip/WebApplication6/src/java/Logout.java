/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import jakarta.servlet.RequestDispatcher;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.util.Date;

/**
 *
 * @author neelj
 */
public class Logout extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session != null) {
            String username = (String) session.getAttribute("username");
            Date startTime = (Date) session.getAttribute("startTime");
            Date endTime = new Date();
            long durationInSeconds = (endTime.getTime() - startTime.getTime()) / 1000;

            session.invalidate();

            request.setAttribute("username", username);
            request.setAttribute("duration", durationInSeconds);
            RequestDispatcher dispatcher = request.getRequestDispatcher("logout.jsp");
            dispatcher.forward(request, response);
        }
    }
}
