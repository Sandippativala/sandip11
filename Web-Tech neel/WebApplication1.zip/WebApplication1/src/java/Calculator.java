/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import jakarta.servlet.RequestDispatcher;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.regex.Pattern;

/**
 *
 * @author neelj
 */
public class Calculator extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        // Fetching all relevant data based on the user's request
        String principalamount_ = request.getParameter("principalamount");
        String rate_ = request.getParameter("rate");
        String years_ = request.getParameter("years");
        String months_ = request.getParameter("months");
        String compoundInterval_ = request.getParameter("compoundinterval");
        
        // Set the value
        request.setAttribute("principalamount", principalamount_);

        // ********** Validation ********** //
        boolean isValid = true;

        // principalamount Validation
        String patternPAmount = "^(100000000|[1-9][0-9]{0,7})$";
        if (Pattern.matches(patternPAmount, principalamount_) == false) {
            request.setAttribute("errorPAmount", "Please enter a valid amount between 1 to 10 crores.");
            isValid = false;
        }

        // Year Validation
        String patternYear = "^(100|[0-9][0-9]{0,1})$";
        if (Pattern.matches(patternYear, years_) == false) {
            request.setAttribute("errorYear", "Please enter a year between 1 to 100.");
            isValid = false;
        }

        // Month Validation
        String patternMonth = "^(10|11|12|[0-9])$";
        if (Pattern.matches(patternMonth, months_) == false) {
            request.setAttribute("errorMonth", "Please enter a month between 1 to 12.");
            isValid = false;
        }

        // Month and Year both zero Validation
        if (years_.equals("0") && months_.equals("0")) {
            request.setAttribute("errorMY", "Month and year both not zero enter.");
        }

        // Compound Interval Validation
        if (compoundInterval_ == null) {
            request.setAttribute("errorCI", "Enter a compound Interval.");
            isValid = false;
        }   

        if (isValid) {
            double principalamount = Double.parseDouble(principalamount_);
            float rate = Float.parseFloat(rate_);
            int years = Integer.parseInt(years_);
            int months = Integer.parseInt(months_);
            int compoundInterval = Integer.parseInt(compoundInterval_);

            // Convert months into years
            float time = (months + (years * 12)) / 12.f;

            // Calculate compound interest
            double futureValue = principalamount * Math.pow((1 + (rate / (compoundInterval * 100))), compoundInterval * time);

            request.setAttribute("pAmount", principalamount);
            request.setAttribute("iRate", rate);
            request.setAttribute("time", time);
            request.setAttribute("cInterval", compoundInterval);
            request.setAttribute("fValue", futureValue);
        }
        RequestDispatcher rd = request.getRequestDispatcher("calculator.jsp");
        rd.forward(request, response);
    }
}
