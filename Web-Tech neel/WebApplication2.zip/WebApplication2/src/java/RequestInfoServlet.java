/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.Enumeration;

/**
 *
 * @author neelj
 */
public class RequestInfoServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter pw = response.getWriter();

        // Get init parameters of the servlet
        pw.println("<h2>Servlet Initialization Parameters</h2>");
        Enumeration<String> initParamNames = getServletConfig().getInitParameterNames();
        String paramName = initParamNames.nextElement();
        String paramValue = getServletConfig().getInitParameter(paramName);
        pw.println("<p>" + paramName + " = " + paramValue + "</p>");

        // HTTP request headers
        pw.println("<h2>HTTP Request Headers:</h2>");
        Enumeration<String> headerNames = request.getHeaderNames();
        while (headerNames.hasMoreElements()) {
            String headerName = headerNames.nextElement();
            String headerValue = request.getHeader(headerName);
            pw.println("<p>" + headerName + " = " + headerValue + "</p>");
        }
        
        // Client/Browser Information
        pw.println("<h2>Client Browser Details:</h2>");
        String clientIP = request.getRemoteAddr();
        String clientBrower = request.getHeader("User-Agent");
        pw.println("<p>Client IP Address= "+clientIP+"</p>");
        pw.println("<p>Client Browser= "+clientBrower+"</p>");

        // server information
        pw.println("<h2>Client/Server Details:</h2>");
        String serverName = request.getServerName();
        int serverPort = request.getServerPort();
        String serverInfo = getServletContext().getServerInfo();
        pw.println("<p>Server Name= " + serverName + "</p>");
        pw.println("Server Port= " + serverPort + "</p>");
        pw.println("Server Information= " + serverInfo + "</p>");
    }
}
