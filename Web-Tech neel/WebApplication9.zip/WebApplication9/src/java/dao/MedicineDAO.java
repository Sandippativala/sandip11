/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import entity.Medicine;
import helper.ConnectionProvider;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author neelj
 */
public class MedicineDAO {

    private Connection connection;

    public MedicineDAO() {
        connection = ConnectionProvider.getConnection();
    }

    public List<Medicine> searchMedicine(String searchPattern) throws SQLException {
        List<Medicine> medicines = new ArrayList<>();
        String sql = "select * from medicines where medicine_name like ? or manufacture_name like ?";
        PreparedStatement psmt = connection.prepareStatement(sql);
        psmt.setString(1, "%"+searchPattern+"%");
        psmt.setString(2, "%"+searchPattern+"%");
        ResultSet rs = psmt.executeQuery();

        while (rs.next()) {
            Medicine medicine = new Medicine();
            medicine.setId(rs.getInt(1));
            medicine.setMedicineName(rs.getString(2));
            medicine.setMedicineDetail(rs.getString(3));
            medicine.setManufactureName(rs.getString(4));
            medicine.setBatchNo(rs.getString(5));
            medicine.setMfgDate(rs.getString(6));
            medicine.setExpDate(rs.getString(7));
            medicines.add(medicine);
        }
        return medicines;
    }

    public List<Medicine> getAllMedicines() throws SQLException {
        List<Medicine> medicines = new ArrayList<>();
        String sql = "select * from medicines";
        PreparedStatement psmt = connection.prepareStatement(sql);
        ResultSet rs = psmt.executeQuery();

        while (rs.next()) {
            Medicine medicine = new Medicine();
            medicine.setId(rs.getInt(1));
            medicine.setMedicineName(rs.getString(2));
            medicine.setMedicineDetail(rs.getString(3));
            medicine.setManufactureName(rs.getString(4));
            medicine.setBatchNo(rs.getString(5));
            medicine.setMfgDate(rs.getString(6));
            medicine.setExpDate(rs.getString(7));
            medicines.add(medicine);
        }
        return medicines;
    }
}
