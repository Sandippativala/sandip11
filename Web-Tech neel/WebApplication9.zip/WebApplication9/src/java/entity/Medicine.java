/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

/**
 *
 * @author neelj
 */
public class Medicine {

    private int id;
    private String medicineName;
    private String medicineDetail;
    private String manufactureName;
    private String batchNo;
    private String mfgDate;
    private String expDate;

    public Medicine(int id, String medicineName, String medicineDetail, String manufactureName, String batchNo, String mfgDate, String expDate) {
        this.id = id;
        this.medicineName = medicineName;
        this.medicineDetail = medicineDetail;
        this.manufactureName = manufactureName;
        this.batchNo = batchNo;
        this.mfgDate = mfgDate;
        this.expDate = expDate;
    }

    public Medicine() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMedicineName() {
        return medicineName;
    }

    public void setMedicineName(String medicineName) {
        this.medicineName = medicineName;
    }

    public String getMedicineDetail() {
        return medicineDetail;
    }

    public void setMedicineDetail(String medicineDetail) {
        this.medicineDetail = medicineDetail;
    }

    public String getManufactureName() {
        return manufactureName;
    }

    public void setManufactureName(String manufactureName) {
        this.manufactureName = manufactureName;
    }

    public String getBatchNo() {
        return batchNo;
    }

    public void setBatchNo(String batchNo) {
        this.batchNo = batchNo;
    }

    public String getMfgDate() {
        return mfgDate;
    }

    public void setMfgDate(String mfgDate) {
        this.mfgDate = mfgDate;
    }

    public String getExpDate() {
        return expDate;
    }

    public void setExpDate(String expDate) {
        this.expDate = expDate;
    }
}
