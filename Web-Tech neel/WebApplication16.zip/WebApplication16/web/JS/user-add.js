function validate() {
    let isValid = true;
    // FirstName Validation
    let firstName = document.getElementById("firstName").value;
    let firstNamePattern = /^[a-zA-Z]{2,40}$/;
    let errorFirstName = document.getElementById("errorFirstName");
    if (firstNamePattern.test(firstName) === false) {
        errorFirstName.innerHTML = "First name must be 2-40 letters, no spaces.";
        isValid = false;
    } else {
        errorFirstName.innerHTML = "";
    }

// LastName Validation
    let lastName = document.getElementById("lastName").value;
    let lastNamePattern = /^[a-zA-Z]{2,40}$/;
    let errorLastName = document.getElementById("errorLastName");
    if (lastNamePattern.test(lastName) === false) {
        errorLastName.innerHTML = "Last name must be 2-40 letters, no spaces.";
        isValid = false;
    } else {
        errorLastName.innerHTML = "";
    }

// City Validation
    let city = document.getElementById("city").value;
    console.log(city);
    let cityPattern = /^[a-zA-Z]{2,40}$/;
    let errorCity = document.getElementById("errorCity");
    if (cityPattern.test(city) === false) {
        errorCity.innerHTML = "City name must be 2-40 letters, no spaces.";
        isValid = false;
    } else {
        errorCity.innerHTML = "";
    }

// Email Validation
    let email = document.getElementById("email").value;
    let emailPattern =
            /^[a-zA-Z0-9._+&*-]+@[a-zA-Z0-9-]+(\.(com|in|org|net|edu|gov|co|info|biz|io|tech|ai|uk|us|au|ca|de|fr|jp|cn|sg|ru|br|za|nz|eu|mil|int|.ac.in|.gov.in|.co.uk|.edu.au|.gov.au|.co.in|.org.in))+$/;
    let errorEmail = document.getElementById("errorEmail");
    if (emailPattern.test(email) === false) {
        errorEmail.innerHTML = "Enter a valid email.";
        isValid = false;
    } else {
        errorEmail.innerHTML = "";
    }

// Mobile Validation
    let mobile = document.getElementById("mobile").value;
    let mobilePattern = /^[0-9]{10}$/;
    let errorMobile = document.getElementById("errorMobile");
    if (mobilePattern.test(mobile) === false) {
        errorMobile.innerHTML = "Enter a valid 10-digit mobile number.";
        isValid = false;
    } else {
        errorMobile.innerHTML = "";
    }
    return isValid;
}