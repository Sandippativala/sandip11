/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

/**
 *
 * @author neelj
 */
public class User {

    private int id;
    private String fName;
    private String lName;
    private String city;
    private String email;
    private String mobile;

    public User(int id, String fName, String lName, String city, String email, String mobile) {
        this.id = id;
        this.fName = fName;
        this.lName = lName;
        this.city = city;
        this.email = email;
        this.mobile = mobile;
    }

    public User(String fName, String lName, String city, String email, String mobile) {
        this.fName = fName;
        this.lName = lName;
        this.city = city;
        this.email = email;
        this.mobile = mobile;
    }

    public User() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getfName() {
        return fName;
    }

    public void setfName(String fName) {
        this.fName = fName;
    }

    public String getlName() {
        return lName;
    }

    public void setlName(String lName) {
        this.lName = lName;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }
}
