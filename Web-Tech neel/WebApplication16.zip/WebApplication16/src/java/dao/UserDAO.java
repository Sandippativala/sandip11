/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import entity.User;
import helper.ConnectionProvider;
import java.sql.*;

/**
 *
 * @author neelj
 */
public class UserDAO {

    private Connection connection;

    public UserDAO() {
        connection = ConnectionProvider.getConnection();
    }

    // Add User
    public boolean addUser(User user) throws SQLException {
        String sql = "insert into user2(fname,lname,city,email,mobile) values(?,?,?,?,?)";
        PreparedStatement psmt = connection.prepareStatement(sql);
        psmt.setString(1, user.getfName());
        psmt.setString(2, user.getlName());
        psmt.setString(3, user.getCity());
        psmt.setString(4, user.getEmail());
        psmt.setString(5, user.getMobile());
        psmt.executeUpdate();
        return true;
    }

    // Fetch User
    public User fetchUser(int id) throws SQLException {
        User user = null;
        String sql = "select * from user2 where id=?";
        PreparedStatement psmt = connection.prepareStatement(sql);
        psmt.setInt(1, id);
        ResultSet rs = psmt.executeQuery();

        if (rs.next()) {
            user = new User();
            user.setId(rs.getInt(1));
            user.setfName(rs.getString(2));
            user.setlName(rs.getString(3));
            user.setCity(rs.getString(4));
            user.setEmail(rs.getString(5));
            user.setMobile(rs.getString(6));
        }
        return user;
    }

    // Update User
    public boolean updateUser(int id, String fName, String lName, String city, String email, String mobile) throws SQLException {
        String sql = "update user2 set fname=?,lname=?,city=?,email=?,mobile=? where id = ?";
        PreparedStatement psmt = connection.prepareStatement(sql);
        psmt.setString(1, fName);
        psmt.setString(2, lName);
        psmt.setString(3, city);
        psmt.setString(4, email);
        psmt.setString(5, mobile);
        psmt.setInt(6, id);
        psmt.executeUpdate();
        return true;
    }

    // Delete User
    public boolean deleteUser(int id) throws SQLException {
        String sql = "delete from user2 where id=?";
        PreparedStatement psmt = connection.prepareStatement(sql);
        psmt.setInt(1, id);
        psmt.executeUpdate();
        return true;
    }
}
