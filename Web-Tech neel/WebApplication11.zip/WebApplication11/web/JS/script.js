function validateForm() {
    var operand1 = document.forms["calcForm"]["operand1"].value;
    var operand2 = document.forms["calcForm"]["operand2"].value;
    var operation = document.querySelector('input[name="operation"]:checked');

    // Check if operands are empty
    if (operand1 === "" || operand2 === "") {
        alert("Please enter both operands.");
        return false;
    }

    // Check if operands are valid numbers
    if (isNaN(operand1) || isNaN(operand2)) {
        alert("Please enter valid numbers for operands.");
        return false;
    }

    // Check if an operation is selected
    if (!operation) {
        alert("Please select an operation.");
        return false;
    }

    // Check for division by zero
    if (operation.value === "Div" && operand2 === 0) {
        alert("Division by zero is not allowed.");
        return false;
    }

    return true;
}