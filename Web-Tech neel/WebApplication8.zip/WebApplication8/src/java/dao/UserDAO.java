/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import entity.User;
import helper.ConnectionProvider;
import java.sql.*;

/**
 *
 * @author neelj
 */
public class UserDAO {

    private Connection con = null;

    public UserDAO() {
        con = ConnectionProvider.getConnection();
    }

    public User getUserByEmailAndPassword(String roll, String email, String password) {
        User u = null;

        try {
            String query = "select * from user,user_roll where user.user_id = user_roll.user_id and roll=? and email=? and password=?";
            PreparedStatement psmt = con.prepareStatement(query);
            psmt.setString(1, roll);
            psmt.setString(2, email);
            psmt.setString(3, password);
            ResultSet rs = psmt.executeQuery();
            if (rs.next()) {
                u = new User();
                u.setUserId(rs.getInt("user_id"));
                u.setFirstName(rs.getString("first_name"));
                u.setLastName(rs.getString("last_name"));
                u.setEmail(rs.getString("email"));
                u.setMobile(rs.getString("mobile"));
                u.setAddress(rs.getString("address"));
                u.setPassword(rs.getString("password"));
                u.setRollId(rs.getInt("roll_id"));
                u.setUserRoll(rs.getString("roll"));
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return u;
    }
}
