function validate() {
    let isValid = true;

    // Roll Validation
    let roll = document.getElementById("roll").value;
    let errorLoginRoll = document.getElementById("errorLoginRoll");
    if (roll === "") {
        errorLoginRoll.innerHTML = "Select the roll.";
        isValid = false;
    } else {
        errorLoginRoll.innerHTML = "";
    }

    // Email Validation
    let email = document.getElementById("email").value.trim();
    let errorLoginEmail = document.getElementById("errorLoginEmail");

    if (email === "") {
        errorLoginEmail.innerHTML = "*";
        isValid = false;
    } else {
        errorLoginEmail.innerHTML = "";
    }

    // Password Validation
    let password = document.getElementById("password").value.trim();
    let errorLoginPassword = document.getElementById("errorLoginPassword");

    if (password === "") {
        errorLoginPassword.innerHTML = "*";
        isValid = false;
    } else {
        errorLoginPassword.innerHTML = "";
    }

    return isValid;
}