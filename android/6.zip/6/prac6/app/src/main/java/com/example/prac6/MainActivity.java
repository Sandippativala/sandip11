package com.example.prac6;

import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.prac6.R;

public class MainActivity extends AppCompatActivity {

    private TextView t1;

    private LinearLayout layoutContainer;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        layoutContainer = findViewById(R.id.layoutContainer);
        Toolbar toolbar = findViewById(R.id.toolbar);
        t1 = findViewById(R.id.color);
        setSupportActionBar(toolbar);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.color_white) {
            layoutContainer.setBackgroundColor(Color.WHITE);
            t1.setText("COLOR : WHITE");

        } else if (id == R.id.color_red) {
            layoutContainer.setBackgroundColor(Color.RED);
            t1.setText("COLOR : RED");
        } else if (id == R.id.color_green) {
            layoutContainer.setBackgroundColor(Color.GREEN);
            t1.setText("COLOR : GREEN");
        } else if (id == R.id.color_blue) {
            layoutContainer.setBackgroundColor(Color.BLUE);
            t1.setText("COLOR : BLUE");
        } else if (id == R.id.color_yellow) {
            layoutContainer.setBackgroundColor(Color.YELLOW);
            t1.setText("COLOR : YELLOW");
        } else if (id == R.id.color_gray) {
            layoutContainer.setBackgroundColor(Color.GRAY);
            t1.setText("COLOR : GRAY");
        } else {
            return super.onOptionsItemSelected(item);
        }

        return true;
    }
}
