package com.example.video;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "VideoPlayer";
    private VideoView videoView;
    private ImageButton btnPlay, btnPrev, btnNext, btnRewind, btnFastForward, btnBack;
    private SeekBar seekBar;
    private TextView txtVideoInfo, txtCurrentTime, txtTotalTime, txtError;
    private ProgressBar progressBar;
    private Handler handler = new Handler();
    private boolean isPlaying = false;
    private int currentPosition = 0;
    private static final int REQUEST_PERMISSION = 101;
    private static final int REWIND_FORWARD_TIME = 10000; // 10 seconds

    private ArrayList<String> videoPaths = new ArrayList<>();
    private int currentVideoIndex = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initializeViews();
        setupButtonListeners();
        checkPermissionsAndLoadVideos();
    }

    private void initializeViews() {
        videoView = findViewById(R.id.videoView);
        btnPlay = findViewById(R.id.btnPlay);
        btnPrev = findViewById(R.id.btnPrev);
        btnNext = findViewById(R.id.btnNext);
        btnRewind = findViewById(R.id.btnRewind);
        btnFastForward = findViewById(R.id.btnFastForward);
        btnBack = findViewById(R.id.btnBack);
        seekBar = findViewById(R.id.seekBar);
        txtVideoInfo = findViewById(R.id.txtVideoInfo);
        txtCurrentTime = findViewById(R.id.txtCurrentTime);
        txtTotalTime = findViewById(R.id.txtTotalTime);
        txtError = findViewById(R.id.txtError);
        progressBar = findViewById(R.id.progressBar);
    }

    private void checkPermissionsAndLoadVideos() {
        String permission;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            // Android 13+ needs READ_MEDIA_VIDEO
            permission = Manifest.permission.READ_MEDIA_VIDEO;
        } else {
            // Older versions use READ_EXTERNAL_STORAGE
            permission = Manifest.permission.READ_EXTERNAL_STORAGE;
        }

        if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
            // Permission not granted, check if we should show explanation
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, permission)) {
                // Show explanation dialog
                showPermissionExplanationDialog(permission);
            } else {
                // No explanation needed, request the permission
                requestStoragePermission(permission);
            }
        } else {
            // Permission already granted
            loadVideosFromStorage();
        }
    }

    private void showPermissionExplanationDialog(final String permission) {
        new AlertDialog.Builder(this)
                .setTitle("Permission Needed")
                .setMessage("This app needs permission to access your videos to play them")
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        requestStoragePermission(permission);
                    }
                })
                .setNegativeButton("Cancel", null)
                .create()
                .show();
    }

    private void requestStoragePermission(String permission) {
        ActivityCompat.requestPermissions(this,
                new String[]{permission},
                REQUEST_PERMISSION);
    }

    private void loadVideosFromStorage() {
        videoPaths.clear();

        String[] projection = {MediaStore.Video.Media.DATA, MediaStore.Video.Media.DISPLAY_NAME};
        String sortOrder = MediaStore.Video.Media.DATE_ADDED + " DESC";

        try (Cursor cursor = getContentResolver().query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                projection,
                null,
                null,
                sortOrder)) {

            if (cursor != null) {
                while (cursor.moveToNext()) {
                    String path = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATA));
                    videoPaths.add(path);
                }

                if (!videoPaths.isEmpty()) {
                    setupVideoPlayer(videoPaths.get(currentVideoIndex));
                } else {
                    showError("No videos found");
                }
            }
        } catch (Exception e) {
            showError("Error loading videos");
            Log.e(TAG, "Error loading videos", e);
        }
    }

    private void showError(String message) {
        runOnUiThread(() -> {
            txtError.setVisibility(View.VISIBLE);
            txtError.setText(message);
            btnPlay.setEnabled(false);
            progressBar.setVisibility(View.GONE);
        });
    }

    private void setupVideoPlayer(String videoPath) {
        runOnUiThread(() -> {
            progressBar.setVisibility(View.VISIBLE);
            txtError.setVisibility(View.GONE);
            btnPlay.setEnabled(false);
        });

        Uri videoUri = Uri.parse(videoPath);
        videoView.setVideoURI(videoUri);

        // Extract video name from path
        String videoName = videoPath.substring(videoPath.lastIndexOf("/") + 1);
        txtVideoInfo.setText(videoName);

        videoView.setOnPreparedListener(mp -> {
            runOnUiThread(() -> {
                progressBar.setVisibility(View.GONE);
                btnPlay.setEnabled(true);
                int duration = videoView.getDuration();
                seekBar.setMax(duration);
                txtTotalTime.setText(formatTime(duration));
            });

            // Auto-start playback
            videoView.start();
            updatePlayPauseState(true);
            handler.post(updateSeekBar);
        });

        videoView.setOnErrorListener((mp, what, extra) -> {
            showError("Error playing video");
            Log.e(TAG, "Video playback error - what:" + what + " extra:" + extra);
            return true;
        });

        videoView.setOnCompletionListener(mp -> {
            updatePlayPauseState(false);
            handler.removeCallbacks(updateSeekBar);
            playNextVideo();
        });
    }

    private void setupButtonListeners() {
        btnPlay.setOnClickListener(v -> {
            if (videoView.isPlaying()) {
                videoView.pause();
                updatePlayPauseState(false);
                handler.removeCallbacks(updateSeekBar);
            } else {
                videoView.start();
                updatePlayPauseState(true);
                handler.post(updateSeekBar);

                // If near end of video, restart from beginning
                if (videoView.getCurrentPosition() > videoView.getDuration() - 2000) {
                    videoView.seekTo(0);
                }
            }
        });

        btnBack.setOnClickListener(v -> finish());

        btnPrev.setOnClickListener(v -> playPreviousVideo());

        btnNext.setOnClickListener(v -> playNextVideo());

        btnRewind.setOnClickListener(v -> {
            int newPosition = videoView.getCurrentPosition() - REWIND_FORWARD_TIME;
            if (newPosition < 0) newPosition = 0;
            videoView.seekTo(newPosition);
            if (!videoView.isPlaying()) {
                txtCurrentTime.setText(formatTime(newPosition));
                seekBar.setProgress(newPosition);
            }
        });

        btnFastForward.setOnClickListener(v -> {
            int newPosition = videoView.getCurrentPosition() + REWIND_FORWARD_TIME;
            if (newPosition > videoView.getDuration()) newPosition = videoView.getDuration();
            videoView.seekTo(newPosition);
            if (!videoView.isPlaying()) {
                txtCurrentTime.setText(formatTime(newPosition));
                seekBar.setProgress(newPosition);
            }
        });

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    videoView.seekTo(progress);
                    txtCurrentTime.setText(formatTime(progress));
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                handler.removeCallbacks(updateSeekBar);
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                handler.post(updateSeekBar);
            }
        });
    }

    private void playNextVideo() {
        if (videoPaths.isEmpty()) return;

        currentVideoIndex = (currentVideoIndex + 1) % videoPaths.size();
        setupVideoPlayer(videoPaths.get(currentVideoIndex));
    }

    private void playPreviousVideo() {
        if (videoPaths.isEmpty()) return;

        currentVideoIndex = (currentVideoIndex - 1 + videoPaths.size()) % videoPaths.size();
        setupVideoPlayer(videoPaths.get(currentVideoIndex));
    }

    private Runnable updateSeekBar = new Runnable() {
        @Override
        public void run() {
            if (videoView.isPlaying()) {
                int currentPosition = videoView.getCurrentPosition();
                seekBar.setProgress(currentPosition);
                txtCurrentTime.setText(formatTime(currentPosition));
                handler.postDelayed(this, 100);
            }
        }
    };

    private void updatePlayPauseState(boolean playing) {
        isPlaying = playing;
        btnPlay.setImageResource(playing ? R.drawable.ic_pause : R.drawable.ic_play);
    }

    private String formatTime(int milliseconds) {
        int seconds = (milliseconds / 1000) % 60;
        int minutes = (milliseconds / (1000 * 60)) % 60;
        int hours = (milliseconds / (1000 * 60 * 60)) % 24;

        return hours > 0
                ? String.format(Locale.getDefault(), "%02d:%02d:%02d", hours, minutes, seconds)
                : String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds);
    }

  


    @Override
    protected void onPause() {
        super.onPause();
        if (videoView.isPlaying()) {
            currentPosition = videoView.getCurrentPosition();
            videoView.pause();
            updatePlayPauseState(false);
        }
        handler.removeCallbacks(updateSeekBar);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (currentPosition > 0) {
            videoView.seekTo(currentPosition);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacks(updateSeekBar);
        videoView.stopPlayback();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, load videos
                loadVideosFromStorage();
            } else {
                // Permission denied
                if (ActivityCompat.shouldShowRequestPermissionRationale(this, permissions[0])) {
                    // User declined but didn't check "never ask again"
                    showPermissionExplanationDialog(permissions[0]);
                } else {
                    // User checked "never ask again" or device policy prevents the app from having this permission
                    showError("Permission denied. Please enable it in app settings");
                    Toast.makeText(this, "Go to Settings > Apps > [This App] > Permissions to enable", Toast.LENGTH_LONG).show();
                }
            }
        }
    }
}