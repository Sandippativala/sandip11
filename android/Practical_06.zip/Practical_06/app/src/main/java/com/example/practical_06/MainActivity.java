package com.example.practical_06;

import android.graphics.Color;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.constraintlayout.widget.ConstraintLayout;

public class MainActivity extends AppCompatActivity {

    private ConstraintLayout constraintLayout;
    private TextView textView, text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        constraintLayout = findViewById(R.id.constraintLayout);
        textView = findViewById(R.id.textView);
        text = findViewById(R.id.text);

        registerForContextMenu(textView);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
//
//        textView.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                openContextMenu(textView);
//            }
//        });
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        getMenuInflater().inflate(R.menu.context_main, menu);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.dark_red) {
            setDarkBackgroundColor(Color.parseColor("#900C3F"));
            return true;
        } else if (id == R.id.dark_green) {
            setDarkBackgroundColor(Color.parseColor("#004D40"));
            return true;
        } else if (id == R.id.white_yellow) {
            setWhiteBackgroundColor(Color.YELLOW);
            return true;
        } else if (id == R.id.white_lightpink) {
            setWhiteBackgroundColor(Color.rgb(255, 182, 193));
            return true;
        }
        return super.onContextItemSelected(item);
    }

    private void setDarkBackgroundColor(int color) {
        constraintLayout.setBackgroundColor(color);
        text.setTextColor(Color.WHITE);
    }

    private void setWhiteBackgroundColor(int color) {
        constraintLayout.setBackgroundColor(color);
        text.setTextColor(Color.BLACK);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.option_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.dark_red) {
            setDarkBackgroundColor(Color.parseColor("#900C3F"));
            return true;
        } else if (id == R.id.dark_green) {
            setDarkBackgroundColor(Color.parseColor("#004D40"));
            return true;
        } else if (id == R.id.white_yellow) {
            setWhiteBackgroundColor(Color.YELLOW);
            return true;
        } else if (id == R.id.white_lightpink) {
            setWhiteBackgroundColor(Color.rgb(255, 182, 193));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
