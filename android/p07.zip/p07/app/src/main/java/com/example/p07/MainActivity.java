package com.example.p07;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText editTextInteger, editTextBoolean, editTextString, editTextFloat, editTextLong;
    private Button buttonSave, buttonLoad, buttonDelete;
    private SharedPreferences sharedPreferences;
    private static final String PREF_NAME = "MyPrefs";
    private static final String KEY_INTEGER = "Integer";
    private static final String KEY_BOOLEAN = "Boolean";
    private static final String KEY_STRING = "String";
    private static final String KEY_FLOAT = "Float";
    private static final String KEY_LONG = "Long";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        editTextInteger = findViewById(R.id.editTextInteger);
        editTextBoolean = findViewById(R.id.editTextBoolean);
        editTextString = findViewById(R.id.editTextString);
        editTextFloat = findViewById(R.id.editTextFloat);
        editTextLong = findViewById(R.id.editTextLong);
        buttonSave = findViewById(R.id.buttonSave);
        buttonLoad = findViewById(R.id.buttonLoad);
        buttonDelete = findViewById(R.id.buttonDelete);


        sharedPreferences = getSharedPreferences(PREF_NAME, MODE_PRIVATE);


        buttonSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putInt(KEY_INTEGER, Integer.parseInt(editTextInteger.getText().toString()));
                editor.putBoolean(KEY_BOOLEAN, Boolean.parseBoolean(editTextBoolean.getText().toString()));
                editor.putString(KEY_STRING, editTextString.getText().toString());
                editor.putFloat(KEY_FLOAT, Float.parseFloat(editTextFloat.getText().toString()));
                editor.putLong(KEY_LONG, Long.parseLong(editTextLong.getText().toString()));
                editor.apply();
                Toast.makeText(MainActivity.this, "Data Saved", Toast.LENGTH_SHORT).show();
            }
        });


        buttonLoad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editTextInteger.setText(String.valueOf(sharedPreferences.getInt(KEY_INTEGER, 0)));
                editTextBoolean.setText(String.valueOf(sharedPreferences.getBoolean(KEY_BOOLEAN, false)));
                editTextString.setText(sharedPreferences.getString(KEY_STRING, ""));
                editTextFloat.setText(String.valueOf(sharedPreferences.getFloat(KEY_FLOAT, 0.0f)));
                editTextLong.setText(String.valueOf(sharedPreferences.getLong(KEY_LONG, 0L)));
                Toast.makeText(MainActivity.this, "Data Loaded", Toast.LENGTH_SHORT).show();
            }
        });


        buttonDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.remove(KEY_INTEGER);
                editor.remove(KEY_BOOLEAN);
                editor.remove(KEY_STRING);
                editor.remove(KEY_FLOAT);
                editor.remove(KEY_LONG);
                editor.apply();
                Toast.makeText(MainActivity.this, "Data Deleted", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
