package com.example.myapplication14;

import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webView);

        webView.setWebViewClient(new WebViewClient()); // Load links in same WebView
        webView.getSettings().setJavaScriptEnabled(true); // Optional: JS support

        webView.loadUrl("https://www.google.com/search?client=firefox-b-d&q=gujarat+vidyapith"); // Replace with any URL you want
    }

    // Handle back button to go back in web history
    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
