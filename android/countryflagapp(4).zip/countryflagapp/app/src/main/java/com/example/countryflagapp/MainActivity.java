package com.example.countryflagapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText editNumber = findViewById(R.id.editNumber);
        Button btnNext = findViewById(R.id.btnNext);

        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String input = editNumber.getText().toString().trim();

                if (input.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Enter a number (1-8)", Toast.LENGTH_SHORT).show();
                    return;
                }

                int number = Integer.parseInt(input);

                if (number < 1 || number > 8) {
                    Toast.makeText(MainActivity.this, "Please enter a number between 1 and 8", Toast.LENGTH_SHORT).show();
                    return;
                }

                Intent intent = new Intent(MainActivity.this, SecondActivity.class);
                intent.putExtra("user_number", number);
                startActivity(intent);
            }
        });
    }
}
