package com.example.countryflagapp;

import static android.R.layout.simple_list_item_1;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.HashMap;

public class SecondActivity extends AppCompatActivity {

    private HashMap<String, Integer> countryFlags;
    private ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        ListView listView = findViewById(R.id.listView);
        imageView = findViewById(R.id.imageView);

        int userNumber = getIntent().getIntExtra("user_number", 1);


        String[] allCountries = {"Lion", "Elephant", "Leapord", "Zebra", "Tiger", "Bear", "parrot", "Deer"};
        int[] flagImages = {R.drawable.lion, R.drawable.elephant, R.drawable.leapord, R.drawable.zebra, R.drawable.tiger,
                 R.drawable.bear, R.drawable.parrot, R.drawable.deer};

        countryFlags = new HashMap<>();
        for (int i = 0; i < allCountries.length; i++) {
            countryFlags.put(allCountries[i], flagImages[i]);
        }

        ArrayList<String> selectedCountries = new ArrayList<>();
        for (int i = 0; i < userNumber; i++) {
            selectedCountries.add(allCountries[i]);
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, simple_list_item_1, selectedCountries);
        listView.setAdapter(adapter);

        // Show first country's flag by default
        if (!selectedCountries.isEmpty()) {
            imageView.setImageResource(countryFlags.get(selectedCountries.get(0)));
            imageView.setVisibility(View.VISIBLE);
        }

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String selectedCountry = selectedCountries.get(position);
                imageView.setImageResource(countryFlags.get(selectedCountry));
            }
        });
    }
}
